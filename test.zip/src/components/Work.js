import React from 'react'

const Work = () => {
  return (
    <div>
      Work Page
    </div>
  )
}

export default Work