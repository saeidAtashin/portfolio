import React from 'react'

const BlogPage = () => {
  return (
    <div>
      Blogs page
    </div>
  )
}

export default BlogPage
