import React from 'react'

const MySkillsPage = () => {
  return (
    <div>
      My Skills page
    </div>
  )
}

export default MySkillsPage
